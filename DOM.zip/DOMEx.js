var image = document.createElement("DIV");
image.id = "myDiv";
image.className ="one"
document.body.appendChild(image);

var classArray = ["one","two","three"];
var buttonContainer = document.createElement("DIV");
buttonContainer.id = "buttonContainer";
document.body.appendChild(buttonContainer);

for(var i = 0; i <classArray.length;i++){
    var button = document.createElement("INPUT");
    button.type = "button";
    button.value = classArray[i];
    button.addEventListener("click",changeImage)
    document.getElementById("buttonContainer").appendChild(button);

}

function changeImage() {
    document.getElementById("myDiv").className=this.value;
}

